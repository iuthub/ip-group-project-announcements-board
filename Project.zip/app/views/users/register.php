<?php require APPROOT . '/views/inc/header.php'; ?>
    <div class="row">
        <div class="col-md-6 mx-auto">
            <div class="card card-body bg-light mt-5">
                <h2>Create An Account</h2>
                <p>Please fill out this form to register with us</p>
                <form action="<?= URLROOT; ?>/users/register" method="post">
                    <div class="form-group">
                        <label for="name">Name: <sup>*</sup></label>
                        <input type="text" name="name" class="form-control form-control-lg <?php echo (!empty($data['name_err'])) ? 'is-invalid' : ''; ?>" value="<?php echo $data['name']; ?>">
                        <span class="invalid-feedback"><?= $data['name_err']; ?></span>
                    </div>
                    <div class="form-group">
                        <label for="email">Email: <sup>*</sup></label>
                        <input type="email" name="email" class="form-control form-control-lg <?php echo (!empty($data['email_err'])) ? 'is-invalid' : ''; ?>" value="<?php echo $data['email']; ?>">
                        <span class="invalid-feedback"><?= $data['email_err']; ?></span>
                    </div>
                    <div class="form-group">
                        <label for="password">Password: <sup>*</sup></label>
                        <input type="password" name="password" class="form-control form-control-lg <?php echo (!empty($data['password_err'])) ? 'is-invalid' : ''; ?>" value="<?php echo $data['password']; ?>">
                        <span class="invalid-feedback"><?= $data['password_err']; ?></span>
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Confirm Password: <sup>*</sup></label>
                        <input type="password" name="confirm_password" class="form-control form-control-lg <?php echo (!empty($data['confirm_password_err'])) ? 'is-invalid' : ''; ?>" value="<?php echo $data['confirm_password']; ?>">
                        <span class="invalid-feedback"><?= $data['confirm_password_err']; ?></span>
                    </div>
                    <div class="form-group">
                        <label for="postal_code">Postal code:<sup>*</sup></label>
                        <input type="text" name="postal_code" class="form-control form-control-lg <?php echo (!empty($data['postal_code_err'])) ? 'is-invalid' : ''; ?>" value="<?php echo $data['postal_code']; ?>">
                        <span class="invalid-feedback"><?= $data['postal_code_err']; ?></span>
                    </div>
                    <div class="form-group">
                        <label for="city">City :<sup>*</sup></label>
                        <input type="text" name="city" class="form-control form-control-lg <?php echo (!empty($data['city_err'])) ? 'is-invalid' : ''; ?>" value="<?php echo $data['city']; ?>">
                        <span class="invalid-feedback"><?= $data['city_err']; ?></span>
                    </div>
                    <div class="form-group">
                        <label for="passport">Passport :<sup>*</sup></label>
                        <input type="text" name="passport" class="form-control form-control-lg <?php echo (!empty($data['passport_err'])) ? 'is-invalid' : ''; ?>" value="<?php echo $data['passport']; ?>">
                        <span class="invalid-feedback"><?= $data['passport_err']; ?></span>
                    </div>
<!--                    <div class="form-group">-->
<!--                        <label for="date_of_birth">Date of birth :<sup>*</sup></label>-->
<!--                        <input type="text" name="date_of_birth" class="form-control form-control-lg --><?php //echo (!empty($data['date_of_birth_err'])) ? 'is-invalid' : ''; ?><!--" value="--><?php //echo $data['date_of_birth']; ?><!--">-->
<!--                        <span class="invalid-feedback">--><?//= $data['date_of_birth_err']; ?><!--</span>-->
<!--                    </div>-->
                    <div class="form-group">
                        <label for="phone_number">Phone number :<sup>*</sup></label>
                        <input type="text" name="phone_number"  id="datepicker"
                               width="276" class="form-control form-control-lg <?php echo (!empty($data['phone_number_err'])) ? 'is-invalid' : ''; ?>" value="<?php echo $data['phone_number']; ?>">
                        <span class="invalid-feedback"><?= $data['phone_number_err']; ?></span>
                    </div>

                    <div class="row">
                        <div class="col">
                            <input type="submit" value="Register" class="btn btn-success btn-block">
                        </div>
                        <div class="col">
                            <a href="<?= URLROOT; ?>/users/login" class="btn btn-light btn-block">Have an account? Login</a>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php require APPROOT . '/views/inc/footer.php'; ?>