<?php require APPROOT . '/views/inc/header.php'; ?>

<?php require APPROOT . '/views/inc/footer.php'; ?>
