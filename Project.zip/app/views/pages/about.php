<?php require APPROOT . '/views/inc/header.php'; ?>
    <section id="all-head-section" class="bg-secondary">
        <div class="container">
            <div class="row">
                <div class="col text-center py-5">
                    <h1 class="display-4">About Us</h1>
                    <p>Announcement board with minimum functional, everything you wanted;)</p>
                    <a href="<?=APPROOT?>" class="btn btn-info" role="button">Go home</a>
                    </button>
                </div>
            </div>
        </div>
    </section>
    <div class="card-columns">
        <div class="card">
            <img
                class="card-img-top img-fluid"
                src="../img/rslogo.jpg"
                alt=""
            />
            <div class="card-body">
                <h4 class="card-title">Card title</h4>
                <p class="card-text text-dark">
                    This is our company LOGO
                </p>
            </div>
        </div>
        <div class="card text-center">
            <div class="card-body">
                <h4 class="card-title">Card title</h4>
                <p class="card-text text-dark">
                    Contact number: +998946279448 <br>
                    Email: dilmurodr00@gmail.com
                </p>
            </div>
        </div>
        <div class="card bg-dark text-white p-3">
            <blockquote class="card-bodyquote">
                <p class="card-text">
                    RUZIYEV <br> DILMUROD
                </p>
                <footer class="blockquote-footer">
                    <small>
                        Backend Developer
                    </small>
                </footer>
            </blockquote>
        </div>
        <hr>
        <div class="card text-center">
            <div class="card-body">
                <h4 class="card-title">Card title</h4>
                <p class="card-text text-dark">
                    Contact number: +998946747564 <br>
                    Email: xansolixonov@gmail.com
                </p>
            </div>
        </div>
        <div class="card bg-dark text-white p-3">
            <blockquote class="card-bodyquote">
                <p class="card-text">
                    SOLIKHONOV <br> QOBILKHON
                </p>
                <footer class="blockquote-footer">
                    <small>
                        Frontend developer
                    </small>
                </footer>
            </blockquote>
        </div>

    </div>
    </div>
<?php require APPROOT . '/views/inc/footer.php'; ?>