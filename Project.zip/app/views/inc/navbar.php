<nav class="navbar navbar-expand-sm navbar-dark bg-dark p-0">
    <div class="container">
      <a href="<?= URLROOT;?>" class="navbar-brand"><?= SITENAME;?></a>
      <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav">
<!--          <li class="nav-item px-2">-->
<!--            <a href="--><?//= URLROOT;?><!--" class="nav-link active">Dashboard</a>-->
<!--          </li>-->
            <div class="nav-link">
          <li class="nav-item px-2">
            <a href="<?= URLROOT;?>/pages/about" class="nav-link">About us</a>
          </li> </div>
<!--          <li class="nav-item px-2">-->
<!--            <a href="--><?//= URLROOT;?><!--/pages/categories" class="nav-link">Categories</a>-->
<!--          </li>-->
<!--          <li class="nav-item px-2">-->
<!--            <a href="--><?//= URLROOT;?><!--/pages/users" class="nav-link">Users</a>-->
<!--          </li>-->

    <div class="nav-link">
        <li class="nav-item">
            <a href="#" class="nav-link"
              <i class="fas fa-user"></i> Welcome  <?php if(isset($_SESSION['user_id'])) : ?>
                <?=($_SESSION['user_name']);?>
                <?php else : ?>
                Guest
                <?php endif; ?>
</a></li></div>

    <?php if(isset($_SESSION['user_id'])) : ?>
              <div class="nav-link">
            <li class="nav-item">
                <a href="<?= URLROOT;?>/users/logout" class="nav-link">
                    <i class="fas fa-user-times"></i> Log out
                </a>
            </li>
              </div>

            <?php else : ?>
            <div class="nav-link">
                <li class="nav-item">
                <a href="<?= URLROOT;?>/users/register" class="nav-link">
                    <i class="fas fa-sign-in-alt"></i> Registration
                </a></li></div>

                <div class="nav-link">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo URLROOT; ?>/users/login">Login</a>
                </li></div>
            <?php endif; ?>

          </li>
        </ul>
      </div>
    </div>
  </nav>