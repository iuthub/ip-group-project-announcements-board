<?php
class Users extends Controller
{

    public function __construct()
    {
        $this -> userModel = $this -> model('User');
    }

    public function register()
    {
        // Check for POST
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            // Process form

            // Sanitize POST data
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            // Init data
            $data = [
                'name' => trim($_POST['name']),
                'email' => trim($_POST['email']),
                'password' => trim($_POST['password']),
                'confirm_password' => trim($_POST['confirm_password']),
                'phone_number' => trim($_POST['phone_number']),
//                'date_of_birth' => trim($_POST['date_of_birth']),
                'postal_code' => trim($_POST['postal_code']),
                'city' => trim($_POST['city']),
                'passport' => trim($_POST['passport']),
                'name_err' => '',
                'email_err' => '',
                'password_err' => '',
                'confirm_password_err' => '',
                'phone_number_err' => '',
//                'date_of_birth_err' => '',
                'postal_code_err' => '',
                'city_err' => '',
                'passport_err' => ''

            ];


            // Validate Name
            if (empty($data['name'])) {
                $data['name_err'] = 'Please enter name';
            } else if (!preg_match('/^[a-zA-Z0-9]{5,}$/', $data['name'])) {
                $data['name_err'] = 'Name must be at least 5 characters';
            }

            // Validate Email
            if (empty($data['email'])) {
                $data['email_err'] = 'Please enter email';
            } else if ($this -> userModel -> findUserByEmail($data['email'])) {
                $data['email_err'] = 'Email is already registered';
            }

            // Validate Password
            if (empty($data['password'])) {
                $data['password_err'] = 'Please enter password';
            } else if (!preg_match('/\w{5,}/', $data['password'])) {
                $data['password_err'] = "Password must contain at least characters (alphanumeric, %,$, -, _, etc)";
            }

            // Validate Confirm Password
            if (empty($data['confirm_password'])) {
                $data['confirm_password_err'] = 'Please confirm password';
            } else {
                if ($data['password'] != $data['confirm_password']) {
                    $data['confirm_password_err'] = 'Passwords do not match';
                }
            }

            // number format (e.g. +998-991234567)
            if (empty($data['phone_number'])) {
                $data['phone_number_err'] = 'Please enter phone number';
            } elseif (!preg_match('/998\d{9}/', $data['phone_number'])) {
                $data['phone_number_err'] = 'Wrong number!';
            }

            //Date of birth which must match the standard date format (e.g. 23-03-1993)
//            if(empty($data['date_of_birth'])){
//                $data['date_of_birth_err'] = 'Please enter date of birth';
//            }

            //Postal code which must contain exactly 7 digits
            if (empty($data['postal_code'])) {
                $data['postal_code_err'] = 'Please enter postal code';
            } elseif (!preg_match('/\d{7}/', $data['postal_code'])) {
                $data['postal_code_err'] = 'Postal code which must contain exactly 7 digits (e.g. 100011)';
            }

            //City name which must contain words only
            if (empty($data['city'])) {
                $data['city_err'] = 'Please enter city';
            } elseif (!preg_match('/\w{1,}/', $data['city'])) {
                $data['city_err'] = 'City must be word';
            }

            //Passport number which match the standard passport number (e.g. AA1234567)
            if (empty($data['passport'])) {
                $data['passport_err'] = 'Please enter passport';
            } elseif (!preg_match('/[A-Z]{2}\d{7}/', $data['passport'])) {
                $data['passport_err'] = 'Passport number which match the standard passport number (e.g. AA1234567)';
            }

            // Make sure errors are empty
            if (empty($data['email_err']) && empty($data['name_err']) && empty($data['password_err']) && empty($data['confirm_password_err']) && empty($data['phone_number_err']) && empty($data['postal_code_err']) && empty($data['city_err']) && empty($data['passport_err'])) {
                // Validated
                // Hash Password
                $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);

                // Register User
                if ($this -> userModel -> register($data)) {
                    flash('register_success', 'You are registered and can log in');
                    redirect('users/login');
                } else {
                    die('Something went wrong');
                }

            } else {
                //&& empty($data['date_of_birth_err'])
                // Load view with errors
                $this -> view('users/register', $data);
            }

        } else {
            // Init data
            $data = [
                'name' => '',
                'email' => '',
                'password' => '',
                'confirm_password' => '',
                'phone_number' => '',
//                'date_of_birth' => '',
                'postal_code' => '',
                'city' => '',
                'passport' => '',
                'name_err' => '',
                'email_err' => '',
                'password_err' => '',
                'confirm_password_err' => '',
                'phone_number_err' => '',
//                'date_of_birth_err' => '',
                'postal_code_err' => '',
                'city_err' => '',
                'passport_err' => ''
            ];

            // Load view
            $this -> view('users/register', $data);
        }
    }

    public function login(){
        // Check for POST
        if($_SERVER['REQUEST_METHOD'] == 'POST'){
            // Process form
            // Sanitize POST data
            $_POST = filter_input_array(INPUT_POST, FILTER_SANITIZE_STRING);

            // Init data
            $data =[
                'email' => trim($_POST['email']),
                'password' => trim($_POST['password']),
                'email_err' => '',
                'password_err' => '',
            ];

            // Validate Email
            if(empty($data['email'])){
                $data['email_err'] = 'Pleae enter email';
            }

            // Validate Password
            if(empty($data['password'])){
                $data['password_err'] = 'Please enter password';
            }

            // Check for user/email
            if($this->userModel->findUserByEmail($data['email'])){
                // User found
            } else {
                // User not found
                $data['email_err'] = 'No user found';
            }

            // Make sure errors are empty
            if(empty($data['email_err']) && empty($data['password_err'])){
                // Validated
                // Check and set logged in user
                $loggedInUser = $this->userModel->login($data['email'], $data['password']);

                if($loggedInUser){
                    // Create Session
                    $this->createUserSession($loggedInUser);
                } else {
                    $data['password_err'] = 'Password incorrect';

                    $this->view('users/login', $data);
                }
            } else {
                // Load view with errors
                $this->view('users/login', $data);
            }


        } else {
            // Init data
            $data =[
                'email' => '',
                'password' => '',
                'email_err' => '',
                'password_err' => '',
            ];

            // Load view
            $this->view('users/login', $data);
        }
    }

    public function createUserSession($user){
        $_SESSION['user_id'] = $user->id;
        $_SESSION['user_email'] = $user->email;
        $_SESSION['user_name'] = $user->name;
        redirect('posts');
    }

    public function logout(){
        unset($_SESSION['user_id']);
        unset($_SESSION['user_email']);
        unset($_SESSION['user_name']);
        session_destroy();
        redirect('users/login');
    }
}