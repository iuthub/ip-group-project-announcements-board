-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 10 2020 г., 20:20
-- Версия сервера: 8.0.15
-- Версия PHP: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `blog`
--

-- --------------------------------------------------------

--
-- Структура таблицы `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `body` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `title`, `body`) VALUES
(3, 0, '3rd task-ku', 'thiiiiird task,baby!'),
(4, 0, '4th task', 'fourth task, this is'),
(6, 0, '6th task', 'wmd'),
(7, 0, 'dsd', 'dsd'),
(8, 0, 'sds', 'ssdscsds'),
(9, 0, 'xa', 'axax'),
(10, 0, 'wdwd', 'sqs'),
(13, 0, '13-th task', 'asdasdasdadsdsda'),
(20, 0, '17th task', 'balallaldladnaldid'),
(21, 0, '199999', 'qwiifasgfiupwegfpwef hf wegfgwe fwe'),
(22, 0, '22th task', 'hv5htin5'),
(23, 0, NULL, NULL),
(24, 0, NULL, NULL),
(25, 0, '25thh task', '35odkfefdo'),
(26, 0, 'uefufheuh  iwdw ', '26----hwhd8whdwidwi'),
(27, 0, 'sssss', 'ssss'),
(28, 0, 'add', 'adadddd'),
(29, 0, 'xaxaxaxx', 'axaxxa'),
(30, 0, 'axaasadcdc', 'asasasasa'),
(31, 0, 'dsdsdsds', 'sdsdsdsdsd'),
(32, 0, 'scscc', 'sccsc'),
(34, 6, 'Hello everyone!', 'This is my first post'),
(36, 8, 'Backend dev', 'I am backend developer of this site , so I will add tasks for other frontend and backend developers'),
(37, 8, 'Qobulxon, please make an \"about us\" page', 'We should introduce ourselves to new comers'),
(38, 9, 'Frontend dev', 'My name is Qobilxon and this is my first post'),
(39, 9, 'Ok,I\'ll do it after deadline!', 'I am frontend developer of this site , so I will tasks for other frontend and backend developers');

-- --------------------------------------------------------

--
-- Структура таблицы `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `categories` varchar(255) DEFAULT NULL,
  `date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `tasks`
--

INSERT INTO `tasks` (`id`, `user_id`, `title`, `content`, `categories`) VALUES
(3, 0, '3rd task-ku', 'thiiiiird task,baby!', NULL),
(4, 0, '4th task', 'fourth task, this is', 'Health'),
(6, 0, '6th task', 'wmd', 'Business'),
(7, 0, 'dsd', 'dsd', 'Tech'),
(8, 0, 'sds', 'ssdscsds', 'Web Development'),
(9, 0, 'xa', 'axax', 'Business'),
(10, 0, 'wdwd', 'sqs', 'Health'),
(13, 0, '13-th task', 'asdasdasdadsdsda', 'Web Development'),
(20, 0, '17th task', 'balallaldladnaldid', 'Business'),
(21, 0, '199999', 'qwiifasgfiupwegfpwef hf wegfgwe fwe', NULL),
(22, 0, '22th task', 'hv5htin5', NULL),
(23, 0, NULL, NULL, NULL),
(24, 0, NULL, NULL, NULL),
(25, 0, '25thh task', '35odkfefdo', 'Web Development'),
(26, 0, 'uefufheuh  iwdw ', '26----hwhd8whdwidwi', 'Business'),
(27, 0, 'sssss', 'ssss', ''),
(28, 0, 'add', 'adadddd', ''),
(29, 0, 'xaxaxaxx', 'axaxxa', 'Business'),
(30, 0, 'axaasadcdc', 'asasasasa', NULL),
(31, 0, 'dsdsdsds', 'sdsdsdsdsd', 'Business'),
(32, 0, 'scscc', 'sccsc', 'Web Development');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `phone_number` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `postal_code` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `city` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `passport` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `phone_number`, `postal_code`, `city`, `passport`) VALUES
(1, 'John Doe', 'JohnDoe@gmail.com', '1212112fsd', '0', '', '', '0'),
(2, 'Marria White', 'marr@wat.com', 'mriaWhite1', '0', '', '', '0'),
(3, 'Mary Johnson', 'maryjohnson@yahoo.com', 'maryyyy123', '0', '', '', '0'),
(4, 'aaaaa11', 'aaa@sas.d', '$2y$10$gv5G6NEKHVtZgmRScI1eIeCQZzdmcT.cVKkkOljMUuSkTBqxqu2/O', '998946279448', '1111111', 'Aasa', 'AA1234567'),
(5, 'asasas', 'asa@sd.ff', '$2y$10$QeurC3Zjsdgv0lnnGLFR4uENyU74abbjdOnOYaKFdYPFD7RF9yA4G', '998987654321', '1234567', 'Tashhhh', 'AA1234567'),
(6, 'aaaaa11', 'aa@gmail.com', '$2y$10$TM0LLMY/4iYiY.EPh4rbTextL6R3D/.BF0TL1FYh1HJuuPD9r7ZE2', '998987654321', '1234567', 'Tashkent', 'AA1234567'),
(7, 'Abdullo', 'Abdullo@gmail.com', '$2y$10$GFUHnQxJJyPNWjc/vFUL9erL327aZy6ErkBK9cMM.TGCn9hgVtgUq', '998946279448', '1234567', 'Tashkent', 'AA1234567'),
(8, 'Dilmurod', 'dilmurodr00@gmail.com', '$2y$10$X4pDMIcF3msFLQaZlJ2NEufHBCKzDaSIGqif2/Peg7KHDKxaUXLxq', '998946279448', '1000001', 'Tashkent city', 'AB1234567'),
(9, 'Qobulxon', 'qsolixonov@aa.com', '$2y$10$/Eo1o.fC3JXWxZ.dIH.lW.KgN1qZLLZ6/paM68lPXGgB4mn4rKG9.', '998987654321', '1122334', 'Toshken', 'CA1234321');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT для таблицы `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
